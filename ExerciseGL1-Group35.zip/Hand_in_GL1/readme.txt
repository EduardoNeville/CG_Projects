%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Task GL1.1: 2D Scene

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Task GL1.1.1: 2D translation in shader

--------------------------------------

We had to edit the vertex shader to apply the translation vertex to make the triangle move when clicked and draged


--------------------------------------

Task GL1.1.2: 2D matrix transform

--------------------------------------

We transformed the triangle position using a translation matrix and a rotation.
This gave us a green triangle that rotated around the center point
And a red triangle that spinned around the [0.5, 0, 0] point

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Task GL1.2: Solar System

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Task GL1.2.1: MVP matrix

--------------------------------------

We calculated the MVP matrix and applied it to the vertex shader to make the vertex end up in it's final position in the output image

--------------------------------------

Task GL1.2.2: View matrix

--------------------------------------

We calculated the view matrix by first calculating the camera position in cartesian coordinates from the given angles and radius, the other vectors were the direction of the camera and the axis (the z-axis)


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Division of work

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

We all worked on the tasks together and discussed the solutions. We all worked on the report together and discussed the solutions. We all worked on the code together and discussed the solutions.

--------------------------------------

Names and SCIPERS

--------------------------------------

Eduardo Neville Castro (314667): 1/3
Natalja Sagel (362089): 1/3
Elias Boschung (315707): 1/3

